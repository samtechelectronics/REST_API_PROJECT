<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registeredproduct extends Model
{
    //
}
