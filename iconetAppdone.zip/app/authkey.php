<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class authkey extends Model
{
    //
}
