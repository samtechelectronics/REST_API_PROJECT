<?php

namespace App;
use App\usersecret;
use App\authkey;
class validate 
{
     public function __construct(){
       

    }
 
}
