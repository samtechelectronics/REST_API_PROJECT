<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\devicehistory;
use App\registeredproduct;
use App\productstatus;
use App\shareddevice;

use Auth;

class historycontroller extends Controller
{
    //
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function getdevicehistory($device_id){

        $device = registeredproduct::where(['product_id' =>  $device_id , 'email' => Auth::user()->email])->first();
        $sdevice = shareddevice::where(['device_id' => $device_id , 'sharedto_id' => Auth::user()->id])->first();
        
           
            $ports =  productstatus::all();
            $users = User::all();
        if(count($device) > 0){
            
            $device_name = $device->product_name;
             $creation_date = $device->created_at;
            $histories = devicehistory::where('device_id' ,$device_id)->get();
 
            return view('user.devicehistory', ['name' => $device_name, 'users' => $users,'histories' => $histories, 'creation_date' =>  $creation_date, 'ports' => $ports , 'device_id' => $device->id]);
        }
        else if(count($sdevice) > 0){
             $device = registeredproduct::where('product_id' , $device_id )->first();
              $device_name = $device->product_name;  
               $creation_date = $device->created_at;
            $histories = devicehistory::where(['device_id' => $device_id , 'user_id' => Auth::user()->id] )->get();

             return view('user.devicehistory', ['name' => $device_name, 'users' => $users,'histories' => $histories, 'creation_date' =>  $creation_date, 'ports' => $ports , 'device_id' => $device->id]);
        }

    	

    }
    public function getporthistory($device_id, $port_id){

            
            $port =  productstatus::where(['product_id' => $device_id , 'id' => $port_id , 'email' => Auth::user()->email])->first();
            $sdevice = shareddevice::where(['device_id' => $device_id , 'sharedto_id' => Auth::user()->id])->first();

            if(count($port) > 0){
                $device = registeredproduct::where('product_id' , $device_id)->first();
                $name = $port->port_name;
                $creation_date = $port->created_at;
                $device_name = $device->product_name;
                 $users = User::all();
                $histories = devicehistory::where(['device_id' => $device_id, 'port_id' => $port_id])->get();
                 return view('user.porthistory', ['device_name' => $device_name, 'name' => $name, 'users' => $users,'histories' => $histories, 'creation_date' =>  $creation_date,'device_id' => $device->id, 'port_id' => $port_id]);

    }
       else if(count($sdevice) > 0){
         $device = registeredproduct::where('product_id' , $device_id)->first();
            $port =  productstatus::where(['product_id' => $device_id , 'id' => $port_id])->first();

                $name = $port->port_name;
                $creation_date = $port->created_at;
                $device_name = $device->product_name;
                 $users = User::all();
                $histories = devicehistory::where(['device_id' => $device_id, 'port_id' => $port_id ,'user_id' => Auth::user()->id])->get();
                 return view('user.porthistory', ['device_name' => $device_name, 'name' => $name, 'users' => $users,'histories' => $histories, 'creation_date' =>  $creation_date,'device_id' => $device->id, 'port_id' => $port_id]);
              
            }
             return     redirect()->back();
}
}
