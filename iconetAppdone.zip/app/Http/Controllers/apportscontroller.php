<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\usersecret;
use App\authkey;
use App\User;
use App\productstatus;
use App\devicehistory;
use App\authhistory;
use App\shareddevice;
use App\registeredproduct;
use Auth;
class apportscontroller extends Controller
{
   public function __construct()
    {
        $this->middleware('auth:api');
    }
public function getports(request $request){

     $this->validate($request,[
            
            "product_id" =>  "required"
            
         ]);
       
            $user = Auth::user();
            $ports = productstatus::where(['email' => $user->email , 'product_id' => $request->product_id])->get();
            
         
         $sdevice = shareddevice::where(['device_id' => $request->product_id , 'sharedto_id' => $user->id])->first();
            if(isset($ports)){
                
                $response['ports'] = $ports;
                $response['code'] = 200;
            return response()->json($response,200);
            }
            else if(isset($sdevice)){
            $user = User::find($sdevice->owner_id);

             $ports = productstatus::where(['email'=> $user->email, 'product_id' => $sdevice->device_id])->get();
             
            $response['ports'] =$ports;
             $response['code'] = 200;
            return response()->json($response,200);
        }
             $response['error'] = "invalid id";
             $response['code'] = 401;
          return response()->json($response,401);
        
}
public function controlport(request $request ){
 $this->validate($request,[
            
            'product_id' => 'required',
            'portid' => 'required',
            
         ]);
        $user_id = $this->authenticate($request);
        
            $user = Auth::User();
            $port = productstatus::where(['product_id' => $request->product_id, 'id'=>$request->portid , 'email'=>$user->email])->first();
        if(isset($port)){
        
           if( $port->new_value == '1'){
             $port->new_value = '0';
             $port->save();
             
             $log = new devicehistory;
             $log->user_id = $user->id;
             $log->action = "ON"; 
             $log->source = "API";
              $log->device_id = $port->product_id;
              $log->port_id = $port->id;
             $log->save();
           }
           else{
            $port->new_value = '1';
             $port->save();
             $log = new devicehistory;
             $log->user_id = $user->id;
             $log->action = "ON"; 
             $log->source = "API";
              $log->device_id = $port->product_id;
              $log->port_id = $port->id;
             $log->save();
           }
           
           $response['response'] = "done";
                $response['code'] = 200;
            return response()->json($response,200);
        }
        else {

             $shareddevice = shareddevice::where(['device_id' => $request->product_id , 'sharedto_id' => $user_id , 'status' => 'active' ])->first();
           if (isset($shareddevice)  ){
              $port = productstatus::where(['product_id' =>$request->product_id, 'id'=> $request->port_id ])->first();
        if(isset($port) ){
        
           if( $port->new_value == '1'){
             $port->new_value = '0';
             $port->save();
            $log = new devicehistory;
             $log->user_id = Auth::user()->id;
             $log->action = "OFF"; 
             $log->source = "WEB";
             $log->device_id = $port->product_id;
             $log->port_id = $port->id;

             $log->save();
           }
           else{
            $port->new_value = '1';
             $port->save();
             $log = new devicehistory;
             $log->user_id = Auth::user()->id;
             $log->action = "ON"; 
             $log->source = "WEB";
             $log->device_id = $port->product_id;
             $log->port_id = $port->id;

             $log->save();
           }
         
           }
           $response['response'] = "done";
                $response['code'] = 200;
            return response()->json($response,200);
        }
    }
  
}


public function editport(request $request){

     $this->validate($request,[
            
           
            'product_id' => 'required',
            'id' => 'required',
            'port_name' => 'required'
            


            
         ]);
        
            $user = Auth::User();
            $port = productstatus::where(['product_id' => $request->product_id, 'id'=>$request->id , 'email'=>$user->email])->first();
          if(isset($port) ){

            $port->port_name = $request->port_name;
            $port->save();
           
              $log = new devicehistory;
             $log->user_id = $user->id;
             $log->action = "Edit"; 
             $log->source = "API";
             $log->device_id = $port->product_id;
             $log->port_id = $port->id;

             $log->save();
             
                $response['code'] = 200;
            return response()->json($response,200);
          }
          else{
            $response['error'] = "invalid request";
                $response['code'] = 202;
            return response()->json($response,200);

          }
    }

public function logout(request $request){
     $this->validate($request,[
            
            'token' => 'required|string',
            'secret' => 'required|string',
         


            
         ]);
        $user_id = $this->authenticate($request);
        if($user_id){
            $token  = authkey::where('auth_token',$request->token)->first();
            $token->auth_token = '';
            $token->save();
              $log = new authhistory;
             $log->user_id = $user_id;
             $log->action = "LOGOUT"; 
             $log->source = "API";
             $log->save();
            return 'logout completed';
        }
        else{
            
                $response['error'] = "invalid user";
                $response['code'] = 303;
            return response()->json($response,303);
        }
}







public function voicecontrol(request $request){
   $querry = $request->all();
   $queryResult = $querry['queryResult'];
   $parameters = $queryResult['parameters'];
   $email = $parameters['email'];
   $password = $parameters['password'];
  if(Auth::attempt(['email' => $email, 'password' => $password])){
    $user = User::where('email' , $email)->first();
     $queryText = $queryResult['queryText'];

       if ($queryText == ""){
         $responce['fulfillmentText'] = "Empty Message sent";
         return response()->json( $responce,200);
    }
    else{
        $splitquerry = explode(" ", $queryText);
       
              if($splitquerry[0] == 'on' || $splitquerry[1] == 'on'){
                  if(isset($splitquerry[4])){
                      $product_name = $splitquerry[4];
                      $product = registeredproduct::where(['email' => $email , 'product_name' => $splitquerry[4] ])->first(); 
                  
                   if(isset($product) ){
                       $port = productstatus::where(['product_id' => $product->product_id, 'port_name'=> $splitquerry[2] ])->first();
                      if(isset($port) ){
                         if($port->new_value == "1"){
                        $responce['fulfillmentText'] =  $splitquerry[2]." in ".$product_name . " is already on";
                        return response()->json( $responce,200);  
                       }
                       else{
                        $port->new_value = "1";
                        $port->save();
                         $log = new devicehistory;
                         $log->user_id = $user->id;
                         $log->action = "ON"; 
                         $log->source = "Google Assistant";
                         $log->device_id = $port->product_id;
                          $log->port_id = $port->id;
                         $log->save();
                         $responce['fulfillmentText'] =  $splitquerry[2]." in ".$product_name . " turned on";
                        return response()->json( $responce,200);  
                       }
                      }else{
                        $responce['fulfillmentText'] = "no device named "  .$splitquerry[2]." in ".$product_name;
                        return response()->json( $responce,200);  
                      }
                   } 
                   else{
                     $responce['fulfillmentText'] = "you have no product name"  .$splitquerry[4]." on iconet";
                        return response()->json( $responce,200);
                   }  
                        
                  }
                  else if (isset($splitquerry[3])) {
                        $product_name = $splitquerry[3];
                        $product = registeredproduct::where(['email' => $email , 'product_name' => $splitquerry[3] ])->first();
                      
                  
                   if(isset($product)  ){
                    
                   $port = productstatus::where(['product_id' =>$product->product_id, 'port_name'=> $splitquerry[1] ])->first();
                   if(isset($port) ){
                         if($port->new_value == "1"){
                        $responce['fulfillmentText'] =  $splitquerry[1]." in ".$product_name . " is already on";
                        return response()->json( $responce,200);  
                       }
                       else{
                        $port->new_value = "1";
                        $port->save();
                         $log = new devicehistory;
                         $log->user_id = $user->id;
                         $log->action = "ON"; 
                         $log->source = "Google Assistant";
                         $log->device_id = $port->product_id;
                          $log->port_id = $port->id;
                         $log->save();
                         $responce['fulfillmentText'] =  $splitquerry[1]." in ".$product_name . " turned on";
                        return response()->json( $responce,200);  
                       }
                      }else{
                        $responce['fulfillmentText'] = "no device named "  .$splitquerry[2]." in ".$product_name;
                        return response()->json( $responce,200);  
                      }
                    
                }
                else{
                  
                   $responce['fulfillmentText'] = "you have no product registered with "  .$splitquerry[3]." on iconet";
                        return response()->json( $responce,200); 
                }
                     
                }
              }
                else if($splitquerry[0] == 'off' || $splitquerry[1] == 'off'){
                        if(isset($splitquerry[4])){
                      $product_name = $splitquerry[4];
                      $product = registeredproduct::where(['email' => $email , 'product_name' => $splitquerry[4] ])->first(); 
                  
                   if(isset($product) ){
                       $port = productstatus::where(['product_id' => $product->product_id, 'port_name'=> $splitquerry[2] ])->first();
                      if(isset($port) ){
                         if($port->new_value == "0"){
                        $responce['fulfillmentText'] =  $splitquerry[2]." in ".$product_name . " is already off";
                        return response()->json( $responce,200);  
                       }
                       else{
                        $port->new_value = "0";
                        $port->save();
                         $log = new devicehistory;
                         $log->user_id = $user->id;
                         $log->action = "OFF"; 
                         $log->source = "Google Assistant";
                         $log->device_id = $port->product_id;
                          $log->port_id = $port->id;
                         $log->save();
                         $responce['fulfillmentText'] =  $splitquerry[2]." in ".$product_name . " turned off";
                        return response()->json( $responce,200);  
                       }
                      }else{
                        $responce['fulfillmentText'] = "no device named "  .$splitquerry[2]." in ".$product_name;
                        return response()->json( $responce,200);  
                      }
                   } 
                   else{
                     $responce['fulfillmentText'] = "you have no product registered with "  .$splitquerry[4]." on iconet";
                        return response()->json( $responce,200);
                   }  
                        
                  }
                  else if (isset($splitquerry[3])) {
                        $product_name = $splitquerry[3];
                        $product = registeredproduct::where(['email' => $email , 'product_name' => $splitquerry[3] ])->first();
                      
                  
                   if(isset($product)  ){
                    
                   $port = productstatus::where(['product_id' =>$product->product_id, 'port_name'=> $splitquerry[1] ])->first();
                   if(isset($port) ){
                         if($port->new_value == "0"){
                        $responce['fulfillmentText'] =  $splitquerry[1]." in ".$product_name . " is already off";
                        return response()->json( $responce,200);  
                       }
                       else{
                        $port->new_value = "0";
                        $port->save();
                         $log = new devicehistory;
                         $log->user_id = $user->id;
                         $log->action = "OFF"; 
                         $log->source = "Google Assistant";
                         $log->device_id = $port->product_id;
                          $log->port_id = $port->id;
                         $log->save();
                         $responce['fulfillmentText'] =  $splitquerry[1]." in ".$product_name . " turned off";
                        return response()->json( $responce,200);  
                       }
                      }else{
                        $responce['fulfillmentText'] = "no  device named "  .$splitquerry[2]." in ".$product_name;
                        return response()->json( $responce,200);  
                      }
                    
                }
                else{
                  
                   $responce['fulfillmentText'] = "you have no product registered with "  .$splitquerry[3]." on iconet";
                        return response()->json( $responce,200); 
                }
                     
                }  
                }
        }
       
        
      
  }
  else {
     $responce['fulfillmentText'] = "your are not registered on iconet";
     return response()->json( $responce,200);
  }
   
    
}



public function getmethod(){
    $devices['code'] = "see your head" ;
                
   return response()->json( $devices,200);
    
}






   public function authenticate($data){

    $secret = usersecret::where('secret', $data->secret)->first();
    $token  = authkey::where('auth_token',$data->token)->first();

    if (isset($secret)  && isset($token) ) {
        if ($secret->user_id == $token->user_id){
            return $secret->user_id;
        }
        else {
            return 0;
        }
    }
    else {
        return 0;
    }
   }  
}
