<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\User;
use App\pcb;
use App\project;
use App\contact;
use Session;
use App\anouncement;
class Usercontroller extends Controller
{
      /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
     $this->middleware('auth:api');
     // $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users=User::all();
        return $users;
        
        return view('admin.viewusers',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('admin.register');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
         $user = new User;
        $this->validate($request,[
            'email'=>'required|unique:User',
            'name'=>'required',
            'password' => 'required|min(4)'
            ]);
        $user->name = $request->name;
         $user->email = $request->email;
         $user->password = bcrypt('$request->password');

        $user->save();
        session()->flash('message','updated successfully');
        return redirect('users.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

       
    }
    public function submitanouncement(Request $request){

       $anouncement = new anouncement;
        $this->validate($request,[
            'message'=>'required',
            'category'=>'required',
            
            ]);
        $anouncement->message = $request->message;
        $anouncement->category = $request->category;
        $anouncement->status = '1';
        $anouncement->save();
        session()->flash('message','Message Sent Success');
        return redirect('admin/message');
    }
    public function sendanouncement(){

        return view('admin.anouncement');
    }


    public function viewanouncement(){
            $anouncements = anouncement::all();
        return view('admin.viewanouncement',compact('anouncements'));
    }
        public function activateanouncement($id)
    {
            $message = anouncement::find($id);
        if($message->status =='1'){
            anouncement::where('id',$id)->update(['status'=>'0']);
        session::flash('status','Message Deactivated successfully');
        return redirect(route('message.view'));

        }
        else if($message->status == '0'){
            anouncement::where('id',$id)->update(['status'=>'1']);
        session::flash('status','Message Activated successfully');
        return redirect(route('message.view'));
       
   } 
}
public function delete($id)
    {
        //
       $item=anouncement::find($id);
       $item->delete();
       session()->flash('status','deleted successfully');
      return redirect('/admin/viewanouncement');
    }








     /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    public function banuser($id)
    {
     $user = User::find($id);
        if($user->status =='1'){
            User::where('id',$id)->update(['status'=>'0']);
        session::flash('status','Your Verifaction was Successful, Please Login');
        return redirect(route('users.index'));

        }
        else if($user->status == '0'){
            User::where('id',$id)->update(['status'=>'1']);
        session::flash('status','Your Verifaction was Successful, Please Login');
        return redirect(route('users.index'));
       
   } 
}

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
         //
        $user = User::find($id);
        return view('admin.edituser',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
         $user =User::find($id);
        $this->validate($request,[
            'name'=>'required',
            'email'=>'required',
            'password' => 'required'
            ]);
        $user->name = $request->name;
         $user->email = $request->email;
         $user->password = bcrypt($request->password);

        $user->save();
        session()->flash('message','updated successfully');
        return redirect('admin/users/create');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   

 public function destroy($id)
    {
        //
       $item=User::find($id);
       $item->delete();
       session()->flash('message','deleted successfully');
      return redirect('/admin/users');
    }

public function getuserdetail($email){

          $pcbs=  DB::table('pcbs')->where('email', $email)->get();
          $projects=DB::table('projects')->where('email', 'email')->get();
          $messages =DB::table('projects')->where('email', $email)->get();
          return  view('admin.viewuser',compact('projects'));
}
}
