<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\usersecret;
use App\authkey;
use App\User;
use App\productstatus;
use App\registeredproduct;
use App\productid;
use App\analogstate;
use App\emptyObject;
use App\devicehistory;
use App\shareddevice;
use Auth;
class apishareddevicecontroller extends Controller
{
     public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function getshare(request $request){
             $this->validate($request,[
          
            "device_id" =>  "required",
         
            ]);
              $device_id = $request->device_id;

            $user = Auth::User();
             $shares = shareddevice::where(['device_id' => $device_id , 'sharedby_id' => $user->id ])->get();
             $device = registeredproduct::where('product_id' , $device_id)->first();
            $device_check = registeredproduct::where(['email' => $user->email , 'product_id' => $device_id])->first();
            $share_check = shareddevice::where(['sharedto_id' => $user->id , 'device_id' => $device_id , 'level' => 'knight' ,'status' => 'active'])->first();
              if(isset($device) ){
            $users = User::all();
        if(isset($device_check)  || isset($share_check) ){
            if(isset($shares) ){
           foreach ($shares as $share) {
             foreach ($users as $user) {
                 if($user->id == $share->owner_id){
                    $share['owner_name'] = $user->username;
                 }
                 if($user->id == $share->sharedby_id){
                     $share['sharedby_name'] = $user->username;
                 }
                 if($user->id  == $share->sharedto_id){
                     $share['sharedto_name'] = $user->username;
                 }
             }
           }
          
           
        }
           
                             $response['data'] = $shares;
                            $response['code'] = 200;
                            return response()->json($response,200);
        }
        else{
                            $response['error'] = "you have no access to this device";
                            $response['code'] = 203;
                            return response()->json($response,200);
        }  
    }
       else{
                        $response['error'] = "device does not exist";
                            $response['code'] = 202;
                            return response()->json($response,200);
        }
     

    }
    //
	public function sharedevice(request $request){
			 $this->validate($request,[
     
            "device_id" =>  "required",
            'email' => 'required|string|email',
            'level' => 'required',
         
            ]);
			 $device_id = $request->device_id;
			 $level = $request->level;
			 $email = $request->email;

    	
    		$sharer = Auth::User();
    		
    		$user = User::where('email', $email)->first();
    		if (isset($user) ){
    		$device = registeredproduct::where(['email' => $sharer->email , 'product_id' => $device_id])->first();

    		$sdevice = shareddevice::where(['sharedto_id' => $sharer->id , 'device_id' => $device_id , 'level' => 'knight'])->first();
    		$shared = shareddevice::where(['device_id' => $device_id , 'sharedto_id' => $user->id ,'status' => 'active'])->first();
    		if(isset($device) ){
    			
    				if($sharer->id == $user->id ){
    					$response['error'] = "cant share to same person";
			    			$response['code'] = 204;
			                return response()->json($response,200);

    				}else{ 
    						if(isset($shared) ){
    							$response['error'] = "the device is already shared to this user";
				    			$response['code'] = 205;
				                return response()->json($response,200);
    						}else{

                                $owner = User::where('email', $device->email)->first();
    							$sharedevice = new shareddevice;
				    			$sharedevice->owner_id = $owner->id;
				    			$sharedevice->sharedby_id= $sharer->id;
				    			$sharedevice->sharedto_id= $user->id;
				    			$sharedevice->status = 'active';
				    			$sharedevice->product_name = $device->product_name;
				    			$sharedevice->device_id = $device_id;
				    			$sharedevice->level = $level;
				    			$sharedevice->save();
                                     $log = new devicehistory;
                                     $log->user_id = $sharer->id;
                                     $log->action = "Share Device"; 
                                     $log->source = "API";
                                     $log->device_id = $device_id;
                                     $log->port_id = 0;
                                     $log->save();
				    			$response['code'] = 200;
			                return response()->json($response,200);
    						}
    						
    				}
    				
    			}
    			

    		
    		else if(isset($sdevice) ){
    			
    					if($sharer->id == $user->id || $user->id == $sdevice->owner_id || $sdevice->owner_id == $sharer->id){
    						$response['error'] = "cant share to same person";
			    			$response['code'] = 204;
			                return response()->json($response,200);
    				}else{
    					if(isset($shared) ){
    							$response['error'] = "the device is already shared to this user";
				    			$response['code'] = 205;
				                return response()->json($response,200);
    						}else{
    					$sharedevice = new shareddevice;
		    			$sharedevice->owner_id = $sdevice->owner_id;
		    			$sharedevice->sharedby_id= $user_id;
		    			$sharedevice->sharedto_id= $user->id;
		    			$sharedevice->status = 'active';
		    			$sharedevice->product_name = $sdevice->product_name;
		    			$sharedevice->device_id = $device_id;
		    			$sharedevice->level = 'pawn';
		    			$sharedevice->save();
                        $log = new devicehistory;
                                     $log->user_id = $user_id;
                                     $log->action = "Share Device"; 
                                     $log->source = "API";
                                     $log->device_id = $device_id;
                                     $log->port_id = 0;
                                     $log->save();
		    			$response['code'] = 200;
			                return response()->json($response,200);
			    		}
    				}
    				
    			}
    				
    		
    		else{
    			$response['error'] = "you dont have such device!!";
    			$response['code'] = 202;
			     return response()->json($response,200);
    		}

    	}
    	else{
    		     $response['error'] = "invalid Email Address!!";
    			 $response['code'] = 202;
			     return response()->json($response,200);
    	}



    
	}

     public function authenticate($data){

    $secret = usersecret::where('secret', $data->secret)->first();
    $token  = authkey::where('auth_token',$data->token)->first();

    if (isset($secret)  && isset($token) ) {
        if ($secret->user_id == $token->user_id){
            return $secret->user_id;
        }
        else {
            return 0;
        }
    }
    else {
        return 0;
    }
   }
}
