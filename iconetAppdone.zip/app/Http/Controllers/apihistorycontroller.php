<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\devicehistory;
use App\registeredproduct;
use App\productstatus;
use App\usersecret;
use App\authkey;
use App\shareddevice;
use Auth;
class apihistorycontroller extends Controller
{
    //
     public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function getdevicehistory(request $request){
    	$this->validate($request,[
            
            
             'device_id' => 'required',

         
            ]);
    	
    	 	$device_id = $request->device_id;
    	 	$user = Auth::User();
    	 	$device = registeredproduct::where(['email' => $user->email, 'product_id' => $device_id])->first();
            $sdevice = shareddevice::where(['device_id' => $device_id , 'sharedto_id' => $user->id])->first();
                $users = User::all();
                $ports =  productstatus::all();
                $portname = "";
    	 	if (isset($device) ) {
    	 		$data['device_name'] = $device->product_name;
    	 		$data['creation_date'] = $device->created_at->toDayDateTimeString();

    	 		$histories = devicehistory::where('device_id' ,$device_id)->orderBy('created_at', 'dec')->get(); 
    	 		foreach($histories as $history){
    	 			
    	 			
    	 			foreach($ports as $port){
    	 				if($port->id == $history->port_id){
    	 					$portname = $port->port_name;
    	 					
    	 				}

    	 			}
    	 			

    	 				$history['port_name'] = $portname;
    	 				$user_name = "";
    	 				$user_email = "";
    	 			foreach($users as $user){
    	 				

    	 				if($user->id  == $history->user_id){
    	 					$user_name = $user->username;
    	 					$user_email = $user->email;
    	 				}

    	 			}
    	 			$history['user_name'] = $user_name;
    	 			$history['user_email'] = $user_email;
    	 		}
    	 	  $data['data'] = $histories;
    	 	  $data['code'] = 200;

    	 	   return response()->json($data,200); 

    	 	}
    	 	else  if(isset($sdevice) ){
                $device = registeredproduct::where('product_id' , $device_id )->first();
                $data['device_name'] = $device->product_name;  
                $data['creation_date'] = $device->created_at->toDayDateTimeString();
            $histories = devicehistory::where(['device_id' => $device_id , 'user_id' => $user_id] )->get();
                foreach($histories as $history){
                    
                    
                    foreach($ports as $port){
                        if($port->id == $history->port_id){
                            $portname = $port->port_name;
                            
                        }

                    }
                    

                        $history['port_name'] = $portname;
                        $user_name = "";
                        $user_email = "";
                    foreach($users as $user){
                        

                        if($user->id  == $history->user_id){
                            $user_name = $user->username;
                            $user_email = $user->email;
                        }

                    }
                    $history['user_name'] = $user_name;
                    $history['user_email'] = $user_email;
                }
                 $data['data'] = $histories;
              $data['code'] = 200;

               return response()->json($data,200); 
    	 			
    	 	}
            else{
                    $response['error'] = "device does not exist";
                $response['code'] = 202;
            return response()->json($response,200);
            }
    	
    }

public function getporthistory(request $request){
	$this->validate($request,[
             'device_id' => 'required',
             'port_id' => 'required'
          
            ]);
    	
    	 	$device_id  = $request->device_id;
    	 	$port_id  = $request->port_id;

    	 	$user = Auth::User();
    	 	$port =  productstatus::where(['product_id' => $device_id , 'id' => $port_id , 'email' => $user->email ])->first();
            $sport = shareddevice::where(['device_id' => $device_id , 'sharedto_id' => $user->id])->first();
            $users = User::all();

            if(isset($port) ){
                $device = registeredproduct::where('product_id' , $device_id)->first();
                $data['port_name'] = $port->port_name;
                $data['creation_date'] =  $port->created_at->format('g:i:sA')."  ".date('jS F Y',strtotime( $port->created_at));;
                $data['device_name'] = $device->product_name;

                $histories = devicehistory::where(['device_id' => $device_id, 'port_id' => $port_id])->orderBy('created_at', 'dec')->get();
                
    	 		foreach($histories as $history){

                    $user_name = "";
                    $user_email = "";
                foreach($users as $user){
    	 				

    	 				if($user->id  == $history->user_id){
    	 					$user_name = $user->username;
    	 					$user_email = $user->email;
    	 				}

    	 			}
    	 			$history['user_name'] = $user_name;
    	 			$history['user_email'] = $user_email;
    	 			}
    	 			

    	 				  $data['data'] = $histories;
    	 	  $data['code'] = 200;

    	 	   return response()->json($data,200); 
    	 		}

	else if (isset($sport) ){
    	 		$device = registeredproduct::where('product_id' , $device_id)->first();
            $port =  productstatus::where(['product_id' => $device_id , 'id' => $port_id])->first();
            $data['port_name'] = $port->port_name;
            $data['creation_date'] =  $port->created_at->format('g:i:sA')."  ".date('jS F Y',strtotime( $port->created_at));;
            $data['device_name'] = $device->product_name;

             $histories = devicehistory::where(['device_id' => $device_id, 'port_id' => $port_id ,'user_id' => $user_id ])->get();
             foreach($histories as $history){

                    $user_name = "";
                    $user_email = "";
                foreach($users as $user){
                        

                        if($user->id  == $history->user_id){
                            $user_name = $user->username;
                            $user_email = $user->email;
                        }

                    }
                    $history['user_name'] = $user_name;
                    $history['user_email'] = $user_email;
                    }
                    

                          $data['data'] = $histories;
              $data['code'] = 200;

               return response()->json($data,200); 

    	 	}
        else{
                $response['error'] = "port dose not exit";
                $response['code'] = 202;
            return response()->json($response,200);
        }
    	
}

  public function authenticate($data){

    $secret = usersecret::where('secret', $data->secret)->first();
    $token  = authkey::where('auth_token',$data->token)->first();

    if (isset($secret)  && isset($token) ) {
        if ($secret->user_id == $token->user_id){
            return $secret->user_id;
        }
        else {
            return 0;
        }
    }
    else {
        return 0;
    }
   }
}

