<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\scheduler;
use App\schedule;
use Session;
use Auth;
use App\usersecret;
use App\authkey;
use App\User;
use App\productstatus;
use App\registeredproduct;
use Carbon\Carbon;
use App\devicehistory;
use App\shareddevice;

class apischedulecontroller extends Controller
{
    //
   public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function getschedules(request $request){
    	 $this->validate($request,[
            
         	'device_id' => 'required',
         	'port_id' => 'required'
            ]);
    	 $device_id = $request->device_id;
    	 $port_id =  $request->port_id;
    
        $users = User::all();
        $user_id = Auth::User()->id;
        $schedules = schedule::where(['device_id' => $device_id , 'port_id' => $port_id , 'user_id' => $user_id ])->get();
       
        $device =  registeredproduct::where('product_id' , $device_id)->first();
        $port = productstatus::find($port_id);
        if(isset($device)  && isset($port) ){
        	 foreach($schedules as $schedule){

            foreach ($users as $user) {
                if($user->id == $schedule->user_id){
                    $schedule['user_name'] = $user->username;

                }

            }
            $schedule->time_on = Carbon::parse($schedule->time_on)->format('g:i:sA')." ".date('jS F Y',strtotime($schedule->time_on));
            $schedule->time_off = Carbon::parse($schedule->time_off)->format('g:i:sA')." ".date('jS F Y',strtotime($schedule->time_off));


           $schedule['creation_date'] =$schedule->created_at->toDayDateTimeString();
         
         
  

            if($schedule->status == 'pending'){
                $scheduler = new scheduler;
             $schedule['time_left'] = $scheduler->getdatedifference(Carbon::now()->format('Y-m-d H:i:s'),$schedule->time_on);
            
            }
            else if($schedule->status == 'active'){
                   $scheduler = new scheduler;
                $schedule['time_left'] = $scheduler->getdatedifference(Carbon::now()->format('Y-m-d H:i:s'), $schedule->time_off);
            }
            else if($schedule->status == 'completed'){
                $schedule['time_left'] = 'None';
            }
            else if($schedule->status == 'cancelled'){
                $schedule['time_left'] = 'Null';
            }



            $schedule['device_name'] = $device->product_name;
            $schedule['port_name'] = $port->port_name;


        }
            $data['data'] = $schedules ;
    	 	$data['code'] = 200 ;
    	  return response()->json( $data,200);
        }
        else{
        	$data['error'] = "wrong device details" ;
    	 	$data['code'] = 202 ;
    	  return response()->json( $data,200);
        }
       
 

}


public function setschedule(request $request){

	    	 $this->validate($request,[
            
            'token' => 'required|string|min:39',
            'secret' => 'required|string|min:39|',
         	'device_id' => 'required',
         	'port_id' => 'required',
         	'date1' => 'required|string|min:19|',
            'date2' => 'required|string|min:19|'
            ]);
    	$user_id = $this->authenticate($request);
    	 if($user_id){
        $user = User::find($user_id);
        $device = registeredproduct::where(['product_id' => $request->device_id , 'email' => $user->email])->first();
       $sdevice = shareddevice::where(['device_id' => $request->device_id , 'sharedto_id' => $user_id])->first();

       if(isset($device)  || isset($sdevice)){
    	 	$scheduler = new scheduler;
            if($scheduler->validateinput($request)){
          
            $schedule = new schedule;
            $schedule->user_id = $user_id;
            $schedule->device_id = $request->device_id;
            $schedule->port_id = $request->port_id;
            $schedule->time_on =  (new Carbon($request->date1))->format('Y-m-d H:i:s'); 
            $schedule->time_off =  (new Carbon($request->date2))->format('Y-m-d H:i:s'); 
            $schedule->status = 'pending';
            $schedule->save();
             $log = new devicehistory;
             $log->user_id = $user->id;
             $log->action = "Set schedule"; 
             $log->source = "API";
             $log->device_id = $request->device_id;
             $log->port_id = $request->port_id;
             $log->save();
    	 	$data['code'] = 200 ;
    	  return response()->json( $data,200);
       
        }
        else{
        	$data['error'] = "invalid time" ;
    	 	$data['code'] = 203 ;
    	  return response()->json( $data,200);
        }
      }else{

          $data['error'] = "invalid device details" ;
        $data['code'] = 202 ;
        return response()->json( $data,200); 
      }

    	 }
    	else{
    	$data['error'] = "wrong details" ;
    	 	$data['code'] = 303 ;
    	  return response()->json( $data,303);
    }

}
public function cancelschedule(request $request){

	    	 $this->validate($request,[
            
            'token' => 'required|string|min:39',
            'secret' => 'required|string|min:39|',
         	'schedule_id' => 'required'
            ]);
    	$user_id = $this->authenticate($request);
    	 if($user_id){


    	 	$id = $request->schedule_id;

         
    	 	$schedule = schedule::find($id);
			    if(isset($schedule) ){
			        
			        if($schedule->user_id == $user_id){
			            $schedule->status = 'cancelled';
			            $schedule->save();
			           	
			    	 	$data['code'] = 200 ;
			    	  return response()->json( $data,200);
			             
			        }
			        else{
			            	$data['error'] = "you did not set these schedule" ;
				    	 	$data['code'] = 203 ;
				    	  return response()->json( $data,200);
			        }
			    }
			else{
			    	$data['error'] = "invalid schedule" ;
			    	 	$data['code'] = 202 ;
			    	  return response()->json( $data,200);
			}
    	 }
    	 else{
    	 		$data['error'] = "wrong details" ;
	    	 	$data['code'] = 303 ;
	    	  return response()->json( $data,303);
    	 }
}
   public function authenticate($data){

    $secret = usersecret::where('secret', $data->secret)->first();
    $token  = authkey::where('auth_token',$data->token)->first();

    if (isset($secret)  && isset($token) ) {
        if ($secret->user_id == $token->user_id){
            return $secret->user_id;
        }
        else {
            return 0;
        }
    }
    else {
        return 0;
    }
   }
   public function test($id){
   	$schedule = schedule::find($id);
   	 $date = date('Y-m-d H:i:s', time());
       $current_date = explode(' ',$date);
       $todaydate = $current_date[0];
       $todaytime = $current_date[1];
       $stat_date = explode(' ',$schedule->time_off);
       $statdate = $stat_date[0];
       $stattime = $stat_date[1];

       $todaydate =explode('-', $todaydate);
       $todaytime =explode(':', $todaytime);
       $statdate =explode('-', $statdate);
       $stattime =explode(':', $stattime);
       
       // if($todaydate[0] >= $statdate[0] && $todaydate[1] >= $statdate[1]){
       // 		if($todaydate[2] > $statdate[2]){
       // 			return 'today is greater';
       // 		}
       // 		else if($todaydate[2] == $statdate[2]){
       // 			return 'the are equal';
       // 		}

       // }
       // else if($todaydate[0] <= $statdate[0] && $todaydate[1] <= $statdate[1]){
       // 		if($todaydate[2] < $statdate[2]){
       // 			return 'today is less';
       // 		}
       // 		else if($todaydate[2] == $statdate[2]){
       // 			return 'the are equal';
       // 		}
       // 	}
       
     
      
   	return $schedule->time_on.'   '.date('Y-m-d H:i:s', time());
   }

}