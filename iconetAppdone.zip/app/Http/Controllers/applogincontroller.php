<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Response;
use App\User;
use App\usersecret;
use App\authkey;
use App\devicekey;
use Auth;
use App\authhistory;

class applogincontroller extends Controller
{
    //
    public function __construct()
    {
     
    }
  public function register(request $request){
  	 $this->validate($request,[
            "username" =>  "required",
            'email' => 'required|string|email|max:255|unique:users',
             'password' => 'required|string|min:6|'
         
            ]);
  	$user = new User;
  	$user->username = $request->username;
  	$user->email = $request->email;
  	$user->password = bcrypt($request->password);
  	 $user->save();
  	$secret = new usersecret;
  	$secret->user_id = $user->id;
  	$secret->secret = Str::random(60);

  	$secret->save();
  	$user->secret = $secret->secret;
  
  	return $user;


  } 
  public function login(request $request){
     // return $request->all();
  	 $this->validate($request,[
            'email' => 'required|string|email',
             'password' => 'required'
         ]);
  	 	
  	 	if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){
  	 	
  	 		$user = User::where('email',$request->email)->first();
        
  	 		$token = authkey::where('user_id',$user->id)->first();
  	 		if(isset($token) ){
  	 			$token->auth_token = Str::random(60);
  	 			$token->save();

  	 		}else{
  	 			$token = new authkey;
  	 			$token->user_id = $user->id;
  	 			$token->auth_token = Str::random(60);
  	 			$token->save();
  	 		}
  	 		$secret = usersecret::where('user_id', $user->id)->first();
  	 		$userdata = User::find($user->id);
  	 		if(isset($secret) ){
  	 			 
    	 	   
  	 			$userdata->secret = $secret->secret;
  	 	
  	 		
  	 		}
  	 		else{
  	 		    $secret = new usersecret;
              	$secret->user_id = $user->id;
              	$secret->secret = Str::random(60);
            
              	$secret->save();
              	$userdata->secret = $secret->secret;
  	 		}
  	 		  $userdata->token = $token->auth_token;
  	 	
  	 		 $log = new authhistory;
             $log->user_id = $userdata->id;
             $log->action = "LOGIN"; 
             $log->source = "API";
            
            
             $log->save();
  	 		return response()->json( $userdata,200);;
  	 	}

  	 	$data['error'] =  'wrong details';
  	 	$data['code'] =  '202';
  	 	return response()->json($data ,401);
  	 
    // $Http = new \GuzzleHttp\Client();
 
    //   try{
    //     $response = $Http->post('http://127.0.0.1:3232/oauth/token', [
    //       'form_params' => [
    //                 "grant_type" => "password",
    //                 "client_id" =>  "2",
    //                 "client_secret" => "vHwc9aj0f7QbkQ7KiJiEhKW7E4rmTMozgl14CPk0",
    //                 "username"  =>  $request->email,
    //                 "password" =>  $request->password,
    //       ]
    //     ]);
    //     return $response->getCode();
    //   }catch(\GuzzleHttp\Exception\BadResponseException $e){
    //     if($e->getCode() == 400){
    //       return response()->json('Invalid Request. Please Enter a Username or Password.', $e->getCode());
    //     }else if($e->getCode() == 401){
    //       return response()->json('Your Credentials are incorrect. please try Again.',$e.getCode() );
    //     }
    //     return response()->json('something is wrong on the server', $e->getCode());
    //   }
   
  }
  public function devicelogin(request $request){
    $this->validate($request,[
            'device_id' => 'required',
             'device_key' => 'required'
         ]);
    
    $device = devicekey::where(['device_id' => $request->device_id , 'device_key' => $request->device_key])->first();
    if (isset($device)) {
      $device->secret_key = Str::random(60);
      $device->save();
      return response()->json($device,200);
    }else{
      return '0';
    }

    
  }
}
