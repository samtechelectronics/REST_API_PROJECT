<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\productstatus;
use App\analogstate;
class productcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request,[
            "id" =>  "required",
            "email" => "required|email",
         
            ]);
          $data = array();
        $user = User::where('email',$request->email)->first();
        if(count($user)>0){
            $apin = analogstate::where(['email'=>$request->email,'product_id'=>$request->id])->get(); 
            if(count($apin)>0){
                $i=1;
               foreach($apin as $state){
                $state->value = $request['pin'.$i];
                $state->save();
                $i++;
               } 
           
            }
           $ports = productstatus::where(['email'=>$request->email,'product_id'=>$request->id])->get(); 
          if(count($ports)>0)
            {
                 foreach($ports as $port){
            $data['pin'.$port->pin_number] = $port->value;
              
           
            }
            $data['id'] =$request->id;
              $data['email'] =$request->email;
             $data['status'] = 200;   
       
           }
           else
           {
          
              $data['id'] =$request->id;
         $data['email'] =$request->email;
         $data['status'] = 406;
           }
           
           
       

        }
        else{
              $data['id'] =$request->id;
         $data['email'] =$request->email;
         $data['status'] = 404;
           }


        return $data;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
