<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\authenticator;
use App\usersecret;
use App\authkey;
use App\User;
use App\productstatus;
use App\registeredproduct;
use App\productid;
use App\analogstate;
use App\emptyObject;
use App\devicehistory;
use App\shareddevice;
use App\devicekey;
use App\wificonfig;
use App\manualhistory;
use Auth;
class appdevicecontroller extends Controller
{
    //
   public function __construct()
    {
        $this->middleware('auth:api');
    }
 
    public function getdevices(request $request){
     
    	 	$user = Auth::User();
    	 	$devices = registeredproduct::where('email',$user->email)->get();
            $pownshared = shareddevice::where(['sharedto_id' => $user->id , 'status' => 'active' , 'level' => 'pawn'])->get();
            $knightshared = shareddevice::where(['sharedto_id' => $user->id , 'status' => 'active' , 'level' => 'knight'])->get();
    	
                $device['data'] = $devices;
                
                foreach($knightshared as $knight){
                   	$product =  registeredproduct::where('product_id',$knight->device_id)->first();
                  
                   	$knight['owner'] =  $product->email;
                   	$knight['product_id'] = $product->product_id;
                   	$knight['port_number'] = $product->port_number;
                   	$knight['product_name'] = $product->product_name;
                  
                    
                }
                 foreach($pownshared as $pown){
                   	$product =  registeredproduct::where('product_id',$pown->device_id)->first();
                  
                   	$pown['owner'] =  $product->email;
                   	$pown['product_id'] = $product->product_id;
                   	$pown['port_number'] = $product->port_number;
                   	$pown['product_name'] = $product->product_name;
                  
                    
                }
                $device['knightshared'] = $knightshared;
    	 		$device['pownshared'] = $pownshared;
    	 		$device['code'] = 200;
    	 		return response()->json( $device,200);

   
    	 	

    	//$devices = registeredproduct::where('email',)->get();
    }
    public function addevice(request $request){
    	 $this->validate($request,[
    
            "product_id" =>  "required",
            "product_name" => "required"
         
            ]);
        
    		$user = Auth::User();
    	  
         $product = productid::where('product_id',$request->product_id)->first();
          
         if(isset($product) ){
            if($product->status == 'unused'){

            	$device = registeredproduct::where('product_id',$request->product_id)->first();
            	if(isset($device)  ){
            		return 'product already registered';
            	}
            	else{
            	$registerproduct = new registeredproduct;
                $registerproduct->product_name = $request->product_name;
                $registerproduct->product_id = $request->product_id;
                $registerproduct->email = $user->email;
                $registerproduct->port_number = $product->port_number;
                $registerproduct->status = 'active';

                $product->status = 'used';
                $registerproduct->save();
                $product->save();

                $isset = 1;
                
                	$this->populateproduct($product->port_number,$request->product_id,$user);
                	$response['code'] = 200;
                  return response()->json($response,200);
            	}
                

             
    	}
    	else{
    			 $response['error'] = 'product is already used';
    		     $response['code'] = 202;
                  return response()->json($response,202);
    		
    	}

    }
    else{
    			$response['error'] = 'product ID does not exit';
    		    $response['code'] = 203;
                return response()->json($response,200);

    }

}
 
    public function editdevice(request $request ){

    	 $this->validate($request,[
            
           
            "product_id" =>  "required",
            "product_name" => "required"
         
            ]);
    	
    		$user = Auth::User();
    		$device = registeredproduct::where(['email' => $user->email , 'product_id' => $request->product_id] )->first();
    		$shared = shareddevice::where(['sharedto_id' => $user->id , 'status' => 'active' , 'device_id' => $request->product_id])->first();
    		if(isset($device) ){
    			$device->product_name = $request->product_name;
    		$device->save();
    		 $log = new devicehistory;
             $log->user_id = $user->id;
             $log->action = "Edit"; 
             $log->source = "API";
             $log->device_id = $device->product_id;
             $log->port_id = 0;
             $log->save();
    		$response['code'] = 200;
            return response()->json($response,200);
    		}
       else if(isset($shared)){
         $shared->product_name = $request->product_name;
    		$shared->save();  
    		$log = new devicehistory;
             $log->user_id = $user->id;
             $log->action = "Edit"; 
             $log->source = "API";
             $log->device_id = $device->product_id;
             $log->port_id = 0;
             $log->save();
    		$response['code'] = 200;
            return response()->json($response,200);
       }
    		else {
    			$response['error'] = "product dose not exit";
    			$response['code'] = 203;
            return response()->json($response,200);
    		}
    		
  
    }
    
     public function authenticate($data){

    $secret = usersecret::where('secret', $data->secret)->first();
    $token  = authkey::where('auth_token',$data->token)->first();

    if (isset($secret)  && isset($token) ) {
        if ($secret->user_id == $token->user_id){
            return $secret->user_id;
        }
        else {
            return 0;
        }
    }
    else {
        return 0;
    }
   }

   public function populateproduct($port,$product_id, $user){

                    for ($i = 1 ; $i < $port + 1 ; $i++){
                        $productstatus = new productstatus;
                        $productstatus->email = $user->email;
                        $productstatus->product_id = $product_id;
                        $productstatus->pin_number =  $i;
                        $productstatus->port_name = 'port'.$i;
                        $productstatus->current_value =  '0';
                        $productstatus->new_value = '0';
                        
                        $productstatus->save();
                    }
                        for ($i = 1 ; $i < 3 ; $i++){
                        $analogstatus = new analogstate;
                        $analogstatus->email = $user->email;
                        $analogstatus->product_id = $product_id;
                        $analogstatus->pin_number =  $i;
                        $analogstatus->value =  '0';
               
                        
                        $analogstatus->save();
                    }
                    return 1;
   }

   public function devicestate(request $request){
       $this->validate($request,[
          'device_key' => 'required|string',
         'secret_key' => 'required|string',
         'portstate' => 'required',
         'manual_action' => 'required'

         ]);  
        $device = devicekey::where(['secret_key' => $request->secret_key , 'device_key' => $request->device_key])->first();
        if(isset($device)){
         $ports = productstatus::where('product_id' ,$device->device_id)->get(); 
         $data = "";
          $port_state = explode(",", $request->portstate);
          $manual_action = explode(",", $request->manual_action);
          if(isset($ports)>0)   {
              $isset =  0;

                 foreach($ports as $port){
                    if($port->previous_value == $port->new_value){
                       $data  = $data."0"; 
                    }
                    else{
                       $data  = $data."1";   
                    }
                    
                $port->previous_value = $port->new_value;
                $port->state = $port_state[$isset];
                $port->save();
                if ($manual_action[$isset] == "0"){
                    $manual_history = new manualhistory;
                    $manual_history->device_id = $device->device_id;
                    $manual_history->port_id = $port->id;
                    $manual_history->action = 'OFF';
                    $manual_history->save();
                }elseif ($manual_action[$isset] == "1") {
                    $manual_history = new manualhistory;
                    $manual_history->device_id = $device->device_id;
                    $manual_history->port_id = $port->id;
                    $manual_history->action = 'ON';
                    $manual_history->save();     
                } 
                    $isset++;


            }
         
            $device_data['new_portstate'] = $data;
            $device_data['error'] = false;

            $wifidetails = wificonfig::where(['device_id' => $device->device_id , 'status' => 'active'])->first();
            if (isset($wifidetails)){
                if($wifidetails->changed_state == 1){
                    $device_data['wifi_state'] = 1;
                }else{
                    $device_data['wifi_state'] = 0; 
                }

                    $device_data['ssid'] = $wifidetails->ssid;
                    $device_data['password'] = $wifidetails->password;

            }
            else{
                    $device_data['wifi_state'] = 2; 
                }



                return $device_data;
      


        }
         else{
            $device_data['error_report'] = "invalid device";
            $device_data['error'] = true;
            return $device_data;
            }
            
   }
   else{
    $device_data['error_report'] = "invalid login";
            $device_data['error'] = true;
            return $device_data;
   }
}
}