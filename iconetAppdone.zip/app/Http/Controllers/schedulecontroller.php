<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\scheduler;
use App\schedule;
use Session;
use Auth;
use App\User;
use App\productstatus;
use App\registeredproduct;
use Carbon\Carbon;
use App\devicehistory;
class schedulecontroller extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function getschedules($device_id,$port_id){
          $scheduler = new scheduler;

        $schedules = schedule::where(['device_id' => $device_id , 'port_id' => $port_id , 'user_id' => Auth::user()->id])->get();
        $users = User::all();
          $scheduler->runschedules(Auth::user()->id);
        $device =  registeredproduct::where('product_id' , $device_id)->first();
        $port = productstatus::find($port_id);
        foreach($schedules as $schedule){

            foreach ($users as $user) {
                if($user->id == $schedule->user_id){
                    $schedule['user_name'] = $user->username;

                }

            }
            $schedule->time_on = Carbon::parse($schedule->time_on);
            $schedule->time_off = Carbon::parse($schedule->time_off);
            if($schedule->status == 'pending'){
                $scheduler = new scheduler;
             $schedule['time_left'] = $scheduler->getdatedifference(Carbon::now()->format('Y-m-d H:i:s'),$schedule->time_on);
            }
            else if($schedule->status == 'active'){
                   $scheduler = new scheduler;
                $schedule['time_left'] = $scheduler->getdatedifference(Carbon::now()->format('Y-m-d H:i:s'), $schedule->time_off);
            }
            else if($schedule->status == 'completed'){
                $schedule['time_left'] = 'None';
            }
            else if($schedule->status == 'cancelled'){
                $schedule['time_left'] = 'Null';
            }


            $schedule['device_name'] = $device->product_name;
            $schedule['port_name'] = $port->port_name;

        }
         //return $schedules;
        //$scheduler = new scheduler;
       // return  $scheduler->getdatedifference($request->date1 , $request->date2);
       return view('user.timer',['device_id' => $device_id , 'port_id' => $port_id , 'schedules' => $schedules ,'key' => $device->id]);
    }
    public function setschedule(request $request){
    	 $this->validate($request,[
            "device_id" =>  "required",
            'port_id' => 'required',
             'date1' => 'required|string|min:19|',
             'date2' => 'required|string|min:19|'
         
            ]);
         
        //  $date = date('Y-m-d H:i:s', time());
        // return  $raw_date = explode(' ',$date);
        //  return strtotime($date).' '.strtotime($request->date1);
        //  return $date = date('Y-m-d H:i:s', time());;
        // $now = strtotime(Carbon::now()->format('Y-m-d H:i:s'));
        //  if($now < strtotime($request->date1) && $now < strtotime($request->date2) ){
        //     return 'true';
        //  }
        //  else{
        //     return 'shit';
        //  }
    	$scheduler = new scheduler;
            if($scheduler->validateinput($request)){
          
            $schedule = new schedule;
            $schedule->user_id = Auth::user()->id;
            $schedule->device_id = $request->device_id;
            $schedule->port_id = $request->port_id;
            $schedule->time_on =  (new Carbon($request->date1))->format('Y-m-d H:i:s'); 
            $schedule->time_off =  (new Carbon($request->date2))->format('Y-m-d H:i:s'); 
            $schedule->status = 'pending';
            $schedule->save();
             $log = new devicehistory;
             $log->user_id = Auth::user()->id;
             $log->action = "Set schedule"; 
             $log->source = "API";
             $log->device_id = $request->device_id;
             $log->port_id = $request->port_id;
             $log->save();
            session()->flash('message','schedule added successfully');
            return redirect()->bacK();
       
        }
        else{
            session()->flash('error','Schedule time invalid!!! start time must be less than stop time');
            return redirect()->bacK();
        }

    
}
public function cancelschedule($id){
    $schedule = schedule::find($id);
    if(count($schedule) > 0){
        
        if($schedule->user_id == Auth::user()->id){
            $schedule->status = 'cancelled';
            $schedule->save();
           
             session()->flash('message','schedule cancelled successfully');
            return redirect()->bacK();
        }
        else{
             session()->flash('error','you did not set this schedule');
            return redirect()->bacK();
        }
    }
else{
     session()->flash('error ','schedule does not exist');
            return redirect()->bacK();
}
}

}
