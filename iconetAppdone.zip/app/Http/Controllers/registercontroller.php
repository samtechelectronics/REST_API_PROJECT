<?php

namespace App\Http\Controllers;
use App\Transformers\UserTransformer;
use Illuminate\Http\Request;
use App\http\Requests\storeuserrequest;
use App\User;
use App\productstatus;
use Illuminate\Support\Facades\Response;
class registercontroller extends Controller
{
    //
  public function getstate($email, $productid){
            
         $ports = productstatus::where(['email' => $email , 'product_id' => $productid])->get(); 
         
         $data = "";
          if(count($ports)>0)   {
                 foreach($ports as $port){
            $data  = $data.$port->new_value;
              
           
            }
            return $data;

    }
    return "none";
}
    public function register(storeuserrequest $request){
    	 $user = new user;
    	 $user->username = $request->username;
    	 $user->email = $request->email;
    	 $user->password =bcrypt( $request->password);
    	 $user->save();
    	 	return response()->json($user,200);

    }
    public function post(request $request){
    	 $this->validate($request,[
            "id" =>  "required",
            "email" => "required|email",
         
            ]);
          $data = array();
    	  $ports = productstatus::where(['email'=>$request->email,'product_id'=>$request->id])->get(); 
          if(count($ports)>0)   {
                 foreach($ports as $port){
            $data['pin'.$port->pin_number] = $port->current_value;
              
           
            }
            $data['id'] =$request->id;
              $data['email'] =$request->email;
             $data['status'] = 200;   
       
           }
           else
           {
           	 $data['id'] =$request->id;
              $data['email'] =$request->email;
             $data['status'] = 200;   
       
           }
    	     
    	 	return response()->json($data,200);
           }

    }
