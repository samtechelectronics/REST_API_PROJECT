<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\apiconfig;
use App\User;
use Auth;

class assitantcontroller extends Controller
{
    //
     public function auth(request $request){
     	 $this->validate($request,[
            "client_id" =>  "required",
            'redirect_uri' => 'required',
            'state' => 'required',
            'response_type' => 'required'
         
            ]);
       $config = new apiconfig;
       $config->client_id = $request->client_id;
       $config->redirect_uri = $request->redirect_uri;
       $config->state = $request->state;
       $config->response_type = $request->response_type;
       $config->save();

       $id = $config->id;

        return view('auth.login',compact('id'));
    }
    public function account(request $request){

         $this->validate($request,[
            "email" =>  "required",
            'password' => 'required',
            'appid' => 'required'
         
            ]);
        
         if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){
          $config = apiconfig::findOrFail($request->appid);
         	$user = User::where('email',$request->email)->first();
        	$user->token = Str::random(60);
        	$user->save();

          $query = http_build_query([
              'client_id' => $config->client_id,
              'access_token' => $user->token,
              'response_type' => $config->response_type,
              'state' =>$config->state
          ]);
          // return $config->redirect_uri.$query;
          return redirect($config->redirect_uri.'#'.$query);
        	

         	
         }
    }
}
