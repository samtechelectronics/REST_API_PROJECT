<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

use App\registeredproduct;
use App\productid;
use Auth;
use App\devicehistory;
use App\shareddevice;
class shareddevicecontroller extends Controller
{
      /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function cancelshare($share_id){
      $shareddevice = shareddevice::find($share_id);
      $shareddevices = shareddevice::where('sharedby_id' ,$shareddevice->user_id )->get();
      $shareddevice->status = 'cancelled';
      $shareddevice->save();
      foreach ($shareddevices as $shareddevice) {
          $shareddevice->status = 'cancelled';
           $shareddevice->save();
      }
      return redirect()->back();

    }
    public function getshareddevices($device_id ,$level){
        $shares = shareddevice::where(['device_id' => $device_id , 'sharedby_id' => Auth::user()->id ])->get();
         $device = registeredproduct::where('product_id' , $device_id)->first();
            
            $device_check = registeredproduct::where(['email' => Auth::user()->email , 'product_id' => $device_id])->first();
            $share_check = shareddevice::where(['sharedto_id' => Auth::user()->id , 'device_id' => $device_id , 'level' => 'knight' ,'status' => 'active'])->first();
    if(isset($device) ){
       $users = User::all();
        if(isset($device_check) || isset($share_check)){
            if(isset($shares) ){
           foreach ($shares as $share) {
             foreach ($users as $user) {
                 if($user->id == $share->owner_id){
                    $share['owner_name'] = $user->username;
                 }
                 if($user->id == $share->sharedby_id){
                     $share['sharedby_name'] = $user->username;
                 }
                 if($user->id  == $share->sharedto_id){
                     $share['sharedto_name'] = $user->username;
                 }
             }
           }
          
           
        }
           return view('user.sharedevice' , ['shares' => $shares , 'device_name' => $device->product_name , 'device_id' => $device_id,'level' => $level]);

        }  
    }
       else{
            return redirect()->back();
        }
        
    }

    public function sharedevice(request $request){
        $this->validate($request,[
        
            "device_id" =>  "required",
            'email' => 'required|string|email',
            'level' => 'required',
         
            ]);

             $device_id = $request->device_id;
             $level = $request->level;
             $email = $request->email;
             $user = User::where('email',$email)->first();
    	    $device = registeredproduct::where(['email' => Auth::user()->email , 'product_id' => $device_id])->first();
            $sdevice = shareddevice::where(['sharedto_id' => Auth::user()->id , 'device_id' => $device_id , 'level' => 'knight'])->first();
           
        
            if(isset($user)){
                 $shared = shareddevice::where(['device_id' => $device_id , 'sharedto_id' => $user->id ,'status' => 'active'])->first();
                 if(isset($device) ){
                
                    if(Auth::user()->id == $user->id ){
                         session()->flash('error',"Cant share with the same User");
                               return redirect()->bacK();
                          
                    }else{ 
                            if(isset($shared) ){
                               
                                session()->flash('error',"the device is already shared to this user");
                               return redirect()->bacK();
                          
                            }else{
                                $sharedevice = new shareddevice;
                                $sharedevice->owner_id = Auth::user()->id;
                                $sharedevice->sharedby_id= Auth::user()->id;
                                $sharedevice->sharedto_id= $user->id;
                                $sharedevice->status = 'active';
                                $sharedevice->product_name = $device->product_name;
                                $sharedevice->device_id = $device_id;
                                $sharedevice->level = $level;
                                $sharedevice->save();
                                $log = new devicehistory;
                                     $log->user_id = Auth::user()->id;
                                     $log->action = "Share Device"; 
                                     $log->source = "WEB";
                                     $log->device_id = $device_id;
                                     $log->port_id = 0;
                                     $log->save();
                               
                           session()->flash('message','Device Shared with '.$email. ' Successfully');
                             
                               return redirect()->bacK();
                            }
                            
                    }
                    
                }
                

            
            else if(isset($sdevice)){
                
                        if(Auth::user()->id == $user->id || $user->id == $sdevice->owner_id || $sdevice->owner_id == Auth::user()->id){
                           
                             session()->flash('error','Cant Share to Same Person');
                               return redirect()->bacK();
                         
                          
                    }else{
                        if(isset($shared) ){
                           
                                session()->flash('error','The Device is Already Shared to This User');
                               return redirect()->bacK();
                                
                            }else{
                        $sharedevice = new shareddevice;
                        $sharedevice->owner_id = $sdevice->owner_id;
                        $sharedevice->sharedby_id= Auth::user()->id;
                        $sharedevice->sharedto_id= $user->id;
                        $sharedevice->status = 'active';
                        $sharedevice->device_id = $device_id;
                        $sharedevice->level = 'pawn';
                        $sharedevice->save();
                        $log = new devicehistory;
                        $log->user_id = Auth::user()->id;
                                     $log->action = "Share Device"; 
                                     $log->source = "WEB";
                                     $log->device_id = $device_id;
                                     $log->port_id = 0;
                                     $log->save();
                        
                           session()->flash('message','Device Shared with '.$email. ' Successfully');
                               return redirect()->bacK();
                        }
                    }
    }
            }
            else{
                     session()->flash('error',"User does not exist");
                               return redirect()->bacK();
                          
            }
           
    
}







}
