<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class wificonfig extends Model
{
    //
}
