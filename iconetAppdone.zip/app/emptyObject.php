<?php

namespace App;



class emptyObject 
{
   $this.data = 3;
   $this.dat1 = 4;
   $this.data2 = 5;
}
