<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('app/register/', 'applogincontroller@register');
Route::get('app/user/', 'Usercontroller@index');
Route::post('app/login/', 'applogincontroller@login');
Route::post('app/devicelogin/', 'applogincontroller@devicelogin');
Route::post('app/getdevices/', 'appdevicecontroller@getdevices');
Route::post('app/devicestate/', 'appdevicecontroller@devicestate');
Route::post('app/addevice', 'appdevicecontroller@addevice');
Route::post('app/editdevice', 'appdevicecontroller@editdevice');
Route::post('app/getports', 'apportscontroller@getports');
Route::post('app/control', 'apportscontroller@controlport');
Route::post('app/editport', 'apportscontroller@editport');
Route::post('app/logout', 'apportscontroller@logout');
Route::get('app/get', 'apportscontroller@getmethod');
Route::post('app/devicehistory/', 'apihistorycontroller@getdevicehistory');
Route::post('app/porthistory/', 'apihistorycontroller@getporthistory');
Route::post('app/schedules/', 'apischedulecontroller@getschedules');
Route::post('app/setschedule/', 'apischedulecontroller@setschedule');
Route::post('app/cancelschedule/', 'apischedulecontroller@cancelschedule');
Route::post('app/sharedevice/', 'apishareddevicecontroller@sharedevice');
Route::post('app/getshare/', 'apishareddevicecontroller@getshare');
Route::get('app/test/{id}', 'apischedulecontroller@test');
Route::post('app/voice', 'apportscontroller@voicecontrol');
