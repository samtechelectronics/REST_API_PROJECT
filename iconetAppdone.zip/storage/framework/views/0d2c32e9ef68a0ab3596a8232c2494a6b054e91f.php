<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="">
 
    	<div class="row">
			<div class="col-md-6">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">PORT CONTROL UNIT</h3>
						
					</div>
					<hr>
					<div class="row">
						<?php 
						$device_id = 0;

						?>
						<?php $__currentLoopData = $ports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
						$device_id = $port->product_id;

						?>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						<div class="col-md-6 col-md-offset-3">
							<a class="btn btn-info" href="/devicehistory/<?php echo e($device_id); ?>">View Device Hisotry</a>
						</div>
						
					</div>
					<hr>
					<table class="table table-hover" id="dev-table">
						<thead>
							<tr>
								<th>#</th>
								<th>PORT Name</th>
								<th>Actions<td>
								
								
							</tr>
						</thead>
						<tbody>
						<?php $i=1; ?>
						<?php $__currentLoopData = $ports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($i); ?></td>
								<?php $i=$i + 1; ?>
								<td><?php echo e($port->port_name); ?></td>
								<td>
									
									<a href="/port/edit/<?php echo e($port->id); ?>"><i class="fa fa-edit">edit name ....</i></a>
									
									<a href="/device/schedule/<?php echo e($port->product_id); ?>/<?php echo e($port->id); ?>"><i class="fa fa-clock-o" aria-hidden="true">schedule task ....</i></a><a href="/porthistory/<?php echo e($port->product_id); ?>/<?php echo e($port->id); ?>"><i class="fa fa-history" aria-hidden="true">history</i></a></td>
								<td>
								<?php if($port->state == '1'): ?>
								<a href="/control/<?php echo e($productid); ?>/<?php echo e($port->id); ?>" class="btn btn-danger">OFF</a>
								<?php else: ?>
								<a href="/control/<?php echo e($productid); ?>/<?php echo e($port->id); ?>" class="btn btn-success"> ON</a> 
								<?php endif; ?>
								<?php if($port->state == '1'): ?>
									<p>
								 <div class="radio radio-success">
                                    <input type="radio" id="singleRadio2<?php echo e($port->id); ?>" value="option2<?php echo e($port->id); ?>" name="radioSingle2<?php echo e($port->id); ?>" checked="" aria-label="Single radio Two">
                                    <label></label>
                                     </div>
								<?php else: ?>
							
								 <div class="radio radio-danger">
                                            <input type="radio" name="radio2<?php echo e($port->id); ?>" id="radio4<?php echo e($port->id); ?>" value="option2<?php echo e($port->id); ?>" checked="">
                                            <label for="radio4">
                                            </label>
                                        </div>

								<?php endif; ?>
								  <?php if($port->new_value == $port->previous_value): ?>
                                        <?php else: ?>
                                        <i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
                                        <span class="sr-only">Loading...</span>
                                        <?php endif; ?>
                                        </p>
								</td>

							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</tbody>
					</table>
				</div>
			</div>
			<div class="col-md-6">
				<div class="panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title">MONITORING UNIT</h3>
						<div class="pull-right">
							<span class="clickable filter" data-toggle="tooltip" title="Toggle table filter" data-container="body">
								<i class="glyphicon glyphicon-filter"></i>
							</span>
						</div>
					</div>
					<div class="panel-body">
						<input type="text" class="form-control" id="task-table-filter" data-action="filter" data-filters="#task-table" placeholder="Filter Tasks" />
					</div>
					<table class="table table-hover" id="task-table">
						<thead>
							<tr>
								<th>#</th>
								<th>Terminal Name</th>
								<th><i class="fa fa-edit"></i></th>
								<th>Value</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>1</td>
								<td>Room temperature</td>
								<td><i class="fa fa-edit"></i></td>
								<td>25 *c</td>
							</tr>
						
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>