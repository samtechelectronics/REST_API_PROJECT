<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.urbanui.com/justdo/template/demo/vertical-default-dark/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 27 Jan 2019 02:20:47 GMT -->
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Iconet</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="/new/vendors/iconfonts/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="/new/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="/new/vendors/css/vendor.bundle.addons.css">
  <link rel="stylesheet" href="/new/vendors/iconfonts/font-awesome/css/font-awesome.min.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="/new/css/vertical-layout-dark/style.css">
  <link rel="stylesheet" href="/new/css/vertical-layout-dark/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="/new/images/favicon.png" />
    <link href="/new/datepicker/css/datetimepicker.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
 
 
</head>
<body>
  <div class="container-scroller" id="app">
   <router-view></router-view>
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="{{ asset('js/app.js') }}"></script>
  <script src="/new/vendors/js/vendor.bundle.base.js"></script>
  <script src="/new/vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="/new/js/off-canvas.js"></script>
  <script src="/new/js/hoverable-collapse.js"></script>
  <script src="/new/js/template.js"></script>
  <script src="/new/js/settings.js"></script>
  <script src="/new/js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="/new/js/dashboard.js"></script>
  <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.0/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="/new/datepicker/js/datetimepicker.js"></script>
     <script type="text/javascript">
    $(document).ready( function () {
        $('#picker').dateTimePicker({
          positionShift: { top: 20, left: -100}
        });  
       
    })
    </script>
  <!-- End custom js for this page-->
</body>


<!-- Mirrored from www.urbanui.com/justdo/template/demo/vertical-default-dark/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 27 Jan 2019 02:21:39 GMT -->
</html>

