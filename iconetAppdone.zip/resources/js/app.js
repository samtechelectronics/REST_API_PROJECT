
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');
import Vue from 'vue/dist/vue.common.js'
window.Vue = Vue;

import VueRouter from 'vue-router'
import { Form, HasError, AlertError } from 'vform'

window.axios = require('axios');

window.Form = Form;
// window.Fire = Fire;
Vue.use(VueRouter)
Vue.config.devtools = false;

let Fire = new Vue();
window.Fire = Fire;



let routes = [
  { path: '/dashboard', component: require('./components/dashboard.vue').default },
  { path: '/profile', component: require('./components/profile.vue').default },
  { path: '/applogin', component: require('./components/login.vue').default },
  { path: '/logout', component: require('./components/logout.vue').default },
  { path: '/share/:id/:level', name: 'share', component: require('./components/sharedevice.vue').default },
  { path: '/history/:id', name: 'devicehistory', component: require('./components/devicehistory.vue').default },
  { path: '/porthistory/:id/:port', name: 'porthistory', component: require('./components/porthistory.vue').default },
  { path: '/schedule/:id/:port', name: 'schedule', component: require('./components/schedule.vue').default },
  { path: '/ports/:id', name: 'ports',  component: require('./components/ports.vue').default }
]

const router = new VueRouter({
	mode: 'history',
  routes // short for `routes: routes`
})
/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */
Vue.component(
    'dashboard',
    require('./components/dashboard.vue').default
);
Vue.component(
    'profile',
    require('./components/profile.vue').default
); 
 Vue.component(
    'login',
    require('./components/login.vue').default
); 
  Vue.component(
    'logout',
    require('./components/logout.vue').default
);
   Vue.component(
    'share',
    require('./components/sharedevice.vue').default
);
    Vue.component(
    'devicehistory',
    require('./components/devicehistory.vue').default
);   
  Vue.component(
    'porthistory',
    require('./components/porthistory.vue').default
); 
  Vue.component(
    'schedule',
    require('./components/schedule.vue').default
); 
  Vue.component(
    'ports',
    require('./components/ports.vue').default
); 



Vue.component(
    'passport-clients',
    require('./components/passport/Clients.vue').default
);

Vue.component(
    'passport-authorized-clients',
    require('./components/passport/AuthorizedClients.vue').default
);
Vue.component(
    'nav_component',
    require('./components/nav.vue').default
);
Vue.component(
    'appfooter',
    require('./components/appfooter.vue').default
);
Vue.component(
    'sidebar',
    require('./components/sidebar.vue').default
);
Vue.component(
    'aside_component',
    require('./components/aside.vue').default
);

Vue.component(
    'passport-personal-access-tokens',
    require('./components/passport/PersonalAccessTokens.vue').default
);
// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))



/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

const app = new Vue({

    el: '#app',
    router
});
