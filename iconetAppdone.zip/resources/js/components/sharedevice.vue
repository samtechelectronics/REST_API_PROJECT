<template>
    <div >
          <nav_component></nav_component>
     <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
     
     <sidebar></sidebar>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
         
           <div class="row">
          
              <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Share Device</h4>
                  <p class="card-description">
                      <h4 class="alert alert-success" v-if="msg">{{message}}</h4>      
                      <h4 class="alert alert-danger" v-if = "err">{{error}}</h4> 
                   </p>
                  <form class="form-inline"  @submit.prevent="sharedevice()">
                    
                  
                    <label class="sr-only" for="inlineFormInputGroupUsername2">User Email</label>
                    <div class="input-group mb-2 mr-sm-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">User Email</div>
                      </div>
                      <input v-model="form.email" type="email" name="email" placeholder="Enter Email"  class="select2_demo_2 form-control" >
                    </div>
                    <label class="sr-only" for="inlineFormInputGroupUsername2">Share Level</label>
                     <div class="input-group mb-2 mr-sm-2">
                          <div class="input-group-prepend">
                        <div class="input-group-text">Share Level</div>
                      </div>
                         
                            <select class="select2_demo_2 form-control" v-model="form.level" name="level"  style="width: 100%">
                                      
                                        
                                        <option value="pawn">pawn</option>
                                        <option value="knight" v-if="level == 'knight'">knight</option>
                                  </select>
                         
                     </div>
                    <!--  <label class="sr-only" for="inlineFormInputGroupUsername2">Select Ports</label>
                     <div class="input-group mb-2 mr-sm-2">
                          
                         
                    <select class="form-control js-example-basic-multiple " style="width: 300px" multiple="multiple">
                      <option value="AL">Alabama</option>
                      <option value="WY">Wyoming</option>
                      <option value="AM">America</option>
                      <option value="CA">Canada</option>
                      <option value="RU">Russia</option>
                    </select>
                         
                     </div> -->
                     <button type="submit" class="btn btn-primary mb-2"> <i class="fa fa-share">Share</i></button>
                    
                  </form>
                </div>
              </div>
            </div>
          </div>


           <div class="row">
            <div class="col-lg-12">
               <div class="card">
            <div class="card-body">
              <h4 class="card-title">Share History</h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                                        <th>Registered By</th>
                                        <th>Shared BY</th>
                                        <th>Shared To</th>
                                        <th>Status</th>
                                        <th>Level</th>
                                        <th>Share Date</th>
                                        <th>Cancelled Date</th>
                                        <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                       
                            <tr v-for="share in shares" :key="share.id">
                                        <td>{{share.owner_name }}</td>
                                       
                                        <td>{{share.sharedby_name }}</td>
                                         <td>{{share.sharedto_name }}</td>
                                         <td> <label class="badge badge-info">{{share.status }}</label></td>
                                         <td>{{share.level }}</td>
                                   
                                
                                          <td>{{share.created_at}}  </td>
                                          <td>{{share.updated_at}}  </td>
                                            <td v-if="share.status == 'active'" >
                                          <button class="btn btn-outline-danger"><i class="fa fa-times"></i></button>
                                      
                                          </td>

                          </tr>
                           
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
            </div>
          </div>


         </div>
         <appfooter></appfooter>
      </div>
    </div>

   
    </div>
</template>

<script>
    export default {
        name: 'share',
        data(){
            return {
                msg: false,
                err: false,
                error: "",
                level: "",
                shares: {},
                form: new Form({
                email: "",
                level: "",
                device_id: ""
                }),

            }
        },

        methods: {
            sharedevice(){
                this.err = false;
                this.msg = false;
                this.error = "";
                this.message = "";

                 this.token = "Bearer "  + localStorage.getItem('access_token');
                        axios.defaults.headers = {
                                'Content-Type': 'application/json',
                                 Authorization: this.token
                            }

                // localStorage.setItem('access_token', data.access_token);
                this.form.device_id = this.$route.params.id;
               axios.post('/api/app/sharedevice',this.form).then((response) => {
                      console.log( response.data);
                       if(response.data.code == undefined){
                       this.err = true;
                       this.error = "Invalid Details, Please Confirm Your Details or Check Your Network Connection";
                      }
                      else if (response.data.code == 200){
                        this.msg = true;
                       this.message = "Shared successfully." ;
                      }
                      else {
                        this.err = true;
                        this.error = response.data.error; 
                      }
                     
                      
                    }).catch(err => {
                    // localStorage.removeItem('user-token') // if the request fails, remove any possible user token if possible
                this.errorstat = true;
                this.error = err.response.data; 
                console.log(err.response.data);
                   this.$router.push('/applogin');
 

                  });  
            },
            loadshares(){

            this.token = "Bearer "  + localStorage.getItem('access_token');
                        axios.defaults.headers = {
                                'Content-Type': 'application/json',
                                 Authorization: this.token
                            }

                // localStorage.setItem('access_token', data.access_token);
               axios.post('/api/app/getshare',{'device_id' : this.$route.params.id }).then((response) => {
                      console.log( response.data.data);
                       if(response.data.data == undefined){
                       this.$router.push('/applogin'); 
                      }
                     
                      this.shares = response.data.data;
                    }).catch(err => {
                    // localStorage.removeItem('user-token') // if the request fails, remove any possible user token if possible
                this.errorstat = true;
                this.error = err.response.data; 
                console.log(err.response.data);
                   this.$router.push('/applogin');
 

                  });  
            }
        

        },
        
        mounted() {
            this.msg = false;
            this.err = false;
            console.log(this.$route.params.id);
            this.level = this.$route.params.level;
            this.loadshares();
        
        }
    }
</script>

