<template>
   <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
         
           <li class="nav-item">
            <a class="nav-link" >
              <i class="ti-home menu-icon"></i>
             <router-link to="/dashboard">Dashboard</router-link>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" >
              <i class="ti-lock menu-icon"></i>
             <router-link to="/logout">logout</router-link>
               </a>    
           </li>
        </ul>
      </nav>
</template>

<script>
    export default {
        mounted() {
            console.log('side bar');
            
        }
    }
</script>




 