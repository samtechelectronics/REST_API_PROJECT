 <template>
    <div>
       <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2019 <a href="/" target="_blank">ICONET EMBEDDED SYSTEM</a>. All rights reserved.</span>
            
          </div>
        </footer> 
    </div>
</template>

<script>
    export default {
        mounted() {
         console.log('footer.');
        }
    }
</script>



