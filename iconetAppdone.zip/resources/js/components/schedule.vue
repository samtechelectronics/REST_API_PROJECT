<template>
    <div class="">
        <nav_component></nav_component>
        <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
     
     <sidebar></sidebar>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
              <div class="row">
                <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Schedule Port Action</h4>
                  <p class="card-description">
                   
                  </p>
                  <form class="form-inline">
                    
                  
                    <label class="sr-only" for="inlineFormInputGroupUsername">Execute Time</label>
                    <div class="input-group mb-2 mr-sm-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">Execute Time</div>
                      </div>
                    <div class="input-group mb-2 mr-sm-2">
                        <div id="picker"> </div>
                        <input type="hidden" id="result" value="" />
                      </div>
                    </div>
                    <label class="sr-only" for="inlineFormInputGroupUsername2">Action</label>
                      <div class="input-group mb-2 mr-sm-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">Action</div>
                      </div>
                    <div class="input-group mb-2 mr-sm-2">
                        <select class="form-control"  id="inlineFormInputGroupUsername2">
                              <option>ON</option>
                              <option>OFF</option>
                             
                         </select>
                      </div>
                    </div>
                   
                    
                    <a href="" class="btn btn-primary mb-2"> <i class="fa fa-share">Schedule</i></a>
                  </form>
                </div>
              </div>
            </div>
              
              </div>
                 <div class="row">
            <div class="col-lg-12">
               <div class="card">
            <div class="card-body">
              <h3 class="alert alert-success">Schedule History</h3>
                <p>
                History of all Schedules set by you on this port.
                 </p>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                          <th>Scheduled By</th>
                          <th>Device Name</th>
                           <th>Port Name</th>
                           <th>Schedule time ON</th>
                           <th>Schedule time OFF</th>
                            <th>Status of Schedule</th>
                            <th>Remaining Time</th>
                            <th>Creation Date</th>
                            <th>Cancel Shedule</th>  
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="schedule in schedules" :key="schedule.id">
                                        <td>{{schedule.user_name }}</td>
                                       
                                        <td>{{schedule.device_name }}</td>
                                         <td>{{schedule.port_name }}</td>
                                         <td>  {{schedule.time_on}}  </td>
                                         <td>  {{schedule.time_off }}</td>
                                         <td>{{schedule.status}}</td>
                                         <td>
                                           {{schedule.time_left}}
                                         </td>
                                          <td>  {{schedule.created_at }}</td>

                                          <td>
                                            <span class="alert alert-danger"><i class="fa fa-times"></i></span>
                                            
                                          
                                           
                                          </td>
                                       
                                    </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "schedule",
        data(){
            return {
            msg: false,
            err: false,
            error: "",
            message: "",
            schedules: {},
            }
        },
        methods:{
            loadschedule(){
                 this.token = "Bearer "  + localStorage.getItem('access_token');
                        axios.defaults.headers = {
                                'Content-Type': 'application/json',
                                 Authorization: this.token
                            }

                // localStorage.setItem('access_token', data.access_token);
               axios.post('/api/app/schedules',{'device_id' : this.$route.params.id ,'port_id' : this.$route.params.port}).then((response) => {
                      console.log( response.data.data);
                    if(response.data.code == undefined){
                       this.err = true;
                       this.error = "Invalid Details, Please Confirm Your Details or Check Your Network Connection";
                      }
                      else if (response.data.code == 200){
                        
                       this.schedules = response.data.data ;
                       


                      }
                      else {
                        this.err = true;
                        this.error = response.data.error; 
                      }
                     
                      this.shares = response.data.data;
                    }).catch(err => {
                    // localStorage.removeItem('user-token') // if the request fails, remove any possible user token if possible
                this.errorstat = true;
                this.error = err.response.data; 
                console.log(err.response.data);
                   this.$router.push('/applogin');
 

                  });  
            }
        },
        mounted() {
            this.loadschedule();
            console.log('login out.');
             // localStorage.removeItem('user-token')
        }
    }
</script>
