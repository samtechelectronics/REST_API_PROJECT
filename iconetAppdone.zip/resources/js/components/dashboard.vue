<template>

    <div >
        <nav_component></nav_component>
        <!-- <aside_component></aside_component> -->
        <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
     
     <sidebar></sidebar>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="row">
                <div class="col-12 col-xl-5 mb-4 mb-xl-0">
                  <h4 class="font-weight-bold">Hi, Welcomeback!</h4>
                </div>
                <div class="col-12 col-xl-7">
                  <div class="d-flex align-items-center justify-content-between flex-wrap">
                   <div class="border-right pr-4 mb-3 mb-xl-0">
                      <p class="text-muted">Total Devices</p>
                      <h4 class="mb-0 font-weight-bold">0</h4>
                    </div>
                    <div class="border-right pr-4 mb-3 mb-xl-0">
                      <p class="text-muted">Devices Owned By Me</p>
                      <h4 class="mb-0 font-weight-bold">0</h4>
                    </div>
                    <div class="border-right pr-4 mb-3 mb-xl-0">
                      <p class="text-muted">Devices Shared To Me</p>
                      <h4 class="mb-0 font-weight-bold">0</h4>
                    </div>
                    <div class="mb-3 mb-xl-0">
                      <button class="btn btn-warning rounded-0 text-white" v-on:click.prevent="createdevice()">Add device</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div  v-for="device  in devices" :key="device.id"  style="padding-bottom: 30px" class="col-md-3 grid-margin grid-margin-md-0 stretch-card">
              <div class="card">
                <div class="card">
                    <!-- <div class="badge badge-warning badge-pill">Shared Device</div> -->
                  
                </div>
                <div class="card-body text-center">
                  <div>
                    <img src="/new/images/dashboard/device.jpg" class="img-lg rounded-circle mb-2" alt="profile image"/>
                    <h4>{{device.product_name}} </h4>
                     <!-- <button class="btn btn-success btn-sm mt-3 mb-4">Open</button> -->
                        <router-link :to="{ name: 'ports', params: {id: device.product_id } }" class="btn btn-success ">
                       Open
                      </router-link>
     
                  </div>
               
                 

                  <div class="border-top pt-3">
                    <div class="row">
                      <div class="col-4">
                        <router-link :to="{ name: 'share', params: {id: device.product_id , level: 'knight' } }" class=""><i class="fa fa-share"></i></router-link> 
                      
                        
                      </div>
                      <div class="col-4">
                        
                      </div>
                      <div class="col-4 ">
                        <a href="" class="pull-right" v-on:click.prevent="editdevice(device)"><i  class="fa fa-pencil"></i> </a>
                       
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             
           
          </div>
            <div class="modal fade" id="editdevice" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel-2" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <form @submit.prevent=" editmode ? saveEditedDevice() : saveNewDevice()">
                      <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalLabel"  v-show = "!editmode">Add New Device </h5>
                          <h5 class="modal-title" id="exampleModalLabel"  v-show = "editmode">Edit  Device </h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                           <h4 class="alert alert-danger" v-if="error != ''">{{ error }}</h4>
                            <div class="form-group">
                            <label>Name</label>
                              <input v-model="form.product_name" placeholder="Name " type="text" name="product_name"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('product_name') }">
                          <!-- <has-error :form="form" field="product_name" ></has-error> -->
                           </div>
                           <div class="form-group" v-if="!editmode">
                                              <label>Product ID</label>
                                              <input v-model="form.product_id" placeholder="Product ID" type="text" name="product_id"
                                                class="form-control" :class="{ 'is-invalid': form.errors.has('product_id') }">
                                             <!--  <has-error :form="form" field="product_id" ></has-error> -->
                                            </div>
                        </div>
                        <div class="modal-footer">
                         <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                  <button type="submit" v-show = "editmode" class="btn btn-primary">Update Device</button>
                                                  <button type="submit"  v-show = "!editmode" class="btn btn-primary" >Add Device</button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
        
              <div class="row" v-if="devicecount != 0">
            <div class="col-md-12 grid-margin">
              <div class="card bg-primary border-0 position-relative">
                <div class="card-body">
                  <p class="card-title text-white">You Have No Iconet Device Registered To This Account.</p>
                 
                </div>
              </div>
            </div>
          </div>
 <!-- conten -->
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       <!-- footer -->
       <appfooter></appfooter>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->

     
    </div>
</template>

<script>
    
    export default {
    name: "dashboard",
            data(){
        return {
          devicecount: 0,
          token: "",
          devices: "",
          vad: "",
          item: {},
          error: {},
        editmode: true,
          devices: {},
         form: new Form({
                product_name:'',
                product_id: '' 
               

            })
        }
        },
       methods: {


          editdevice(device){
            this.error = "";

          this.editmode = true;
          this.form.reset();
          $('#editdevice').modal('show');
          this.form.fill(device);

          },
           createdevice(){
            this.error = "";
          this.editmode = false;
          console.log('create mode');
          
          this.form.reset();
           $('#editdevice').modal('show');


        },
        saveNewDevice(){
          this.form.post('api/app/addevice').then((response) => {
            console.log(response);
            if(response.data.code == undefined){
              this.error = "Invalid Data. Check Your Network Connection";
            }
            else if(response.data.code == 200){
               $('#editdevice').modal('hide');
               Fire.$emit('reload');
            }
            else {
              this.error = response.data.error;
            } 
          
          
          });

        
        },
        saveEditedDevice(){
        this.form.post('api/app/editdevice').then((response) => {
          this.error = response.data.code;
            console.log(response);
              if(response.data.code == undefined){
            this.error = "Invalid Data. Check Your Network Connection";
          }
          else if(response.data.code == 200){
           $('#editdevice').modal('hide');
           Fire.$emit('reload');

          }
           }
          );
        
        

        },
         loaddevices(){
             this.token = "Bearer "  + localStorage.getItem('access_token');
                        axios.defaults.headers = {
                                'Content-Type': 'application/json',
                                 Authorization: this.token
                            }

                // localStorage.setItem('access_token', data.access_token);
                   axios.post('/api/app/getdevices', this.form).then((response) => {
                      console.log(response.data.data);
                      if(response.data.data == undefined){
                       this.$router.push('/applogin'); 
                      }
                     
                        this.devices = response.data.data;
                   
                    }).catch(err => {
                    // localStorage.removeItem('user-token') // if the request fails, remove any possible user token if possible
                this.errorstat = true;
                this.error = err.response.data; 
                console.log(err.response.data);
                   this.$router.push('/applogin');


                  });
        }
        
      },
        mounted() {
            this.loaddevices();

            console.log('Component mounted.');

            Fire.$on('reload', () => {
            this.loaddevices();
          })
          
        }
    }
</script>
